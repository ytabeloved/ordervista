import api from "../api/api";

export async function createOrder(orderData) {
    const response = await api.post("/orders", orderData);
    return response.data;
}

export async function createInPersonOrder(orderData) {
    const response = await api.post("/orders/in-person", orderData);
    return response.data;
}

export async function getOrders() {
    const response = await api.get("/orders");
    return response.data;
}

export async function getOrderDetail(idPedido) {
    const response = await api.get(`/orders/${idPedido}`);
    return response.data;
}

export async function getManagedOrders() {
    const response = await api.get("/orders/manage");
    return response.data;
}

export async function getManagedOrderDetail(idPedido) {
    const response = await api.get(`/orders/manage/${idPedido}`);
    return response.data;
}

export async function updateManagedOrderStatus(idPedido, idEstado) {
    const response = await api.patch(`/orders/manage/${idPedido}/status`, {
        id_estado: idEstado
    });

    return response.data;
}